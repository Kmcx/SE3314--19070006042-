package org.example;

import junit.framework.TestCase;

public class RentalRecordTest extends TestCase {
    /**
     * Smoke test for the car rental system.
     */
    public void testCarRentalSystem() {
        // Creating a luxury vehicle with GPS and leather seats features
        LuxuryVehicle luxuryCar = new LuxuryVehicle("BMW", "X5", "ABC123",
                new GPS(), new LeatherSeats());

        // Creating an economy vehicle with hybrid feature
        EconomyVehicle economyCar = new EconomyVehicle("Toyota", "Prius", "XYZ789",
                new Hybrid());

        // Creating rental records
        RentalRecord rentalRecordLuxury = new RentalRecord(luxuryCar, 5, "John Doe");
        RentalRecord rentalRecordEconomy = new RentalRecord(economyCar, 3, "Jane Smith");

        // Calculating total rental cost
        double totalCostLuxury = rentalRecordLuxury.getTotalRentalCost();
        double totalCostEconomy = rentalRecordEconomy.getTotalRentalCost();

        // Printing total rental cost
        System.out.println("Total rental cost for luxury car: $" + totalCostLuxury);
        System.out.println("Total rental cost for economy car: $" + totalCostEconomy);
    }


}