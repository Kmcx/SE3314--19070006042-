package org.example;
/**
 * Calculates the additional cost for the feature based on the rental days.
 *
 * @param rentalDays The number of days the feature is rented.
 * @return The additional cost for the feature.
 */
public interface AdditionalFeatureAbstract {
    double calculateAdditionalCost(int rentalDays);
}
